package runtime;

public class Dec extends Instruction {

	Dec(int code, String mnemonic) {
		super(code,mnemonic);
	}

}
