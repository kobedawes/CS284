package runtime;

public class Div extends Instruction {
  
	Div(int code, String mnemonic) {
		super(code,mnemonic);
	}
	
	
}
