package runtime;

public class Sub extends Instruction {
  
	Sub(int code, String mnemonic) {
		super(code,mnemonic);
	}
	
	
}
